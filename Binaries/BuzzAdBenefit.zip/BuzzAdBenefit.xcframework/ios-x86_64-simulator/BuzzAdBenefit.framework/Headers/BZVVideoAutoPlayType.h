@import Foundation;

typedef NS_ENUM(NSUInteger, BZVVideoAutoPlayType) {
  BZVVideoAutoPlayNotSet,
  BZVVideoAutoPlayDisabled,
  BZVVideoAutoPlayEnabled,
  BZVVideoAutoPlayOnWifi
};
